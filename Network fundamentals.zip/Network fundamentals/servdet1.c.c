/* To get the detatls of all entrtes avatlable in /etc/services (servtces
database).
Verston: 1.0
Author: Team -c*/
# include <netdb.h>
# include <stdio.h>
main(){
    char **names;
    int i;
    struct servent *se=NULL;
    while( (se = getservent()) !=NULL){
    printf("-- --\n");
    printf(" official Service Name = %s\n",se->s_name);
    printf("Port no = %d\n",ntohs(se->s_port));
    printf("Protocol %s\n",se->s_proto);
    names = se->s_aliases;
    for (i=0; names[i]!=NULL;i++)
            printf("...%s...\n",names[i]); 
    printf("---------------\n");
    }
}